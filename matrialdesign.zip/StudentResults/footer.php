</div>

   
  
  <!-- End your project here-->
<script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
  <!-- jQuery -->
  <!-- Bootstrap js -->
 <script type="text/javascript" src="dist/js/bootstrap.min.js"  crossorigin="anonymous"></script>
  
  </body>
</html>